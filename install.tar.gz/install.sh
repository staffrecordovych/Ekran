#!/bin/bash
source .resolver.sh

SYSTEM=linux
./install.sh $@