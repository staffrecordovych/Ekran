#!/bin/bash
cd "$(dirname $BASH_SOURCE[0])"

touch /tmp/SytecaMaintenance

while getopts "fs" opt; do
    case $opt in
        f)
            FORCED=1
            REMOVE_SETTINGS=1
        ;;
        s)
            REMOVE_SETTINGS=1
        ;;
        \? ) exit 1
    esac
done


unset LD_PRELOAD
unset LDR_PRELOAD
unset LDR_PRELOAD64
unset LD_PRELOAD_32
unset LD_PRELOAD_64

if [[ $EUID -ne 0 ]]; then
    echo "You must be a root user"
    exit 1
fi

if [[ "$(uname)" == "Linux" && -e './uninstall-recorderGUI.sh' ]]; then
    ./uninstall-recorderGUI.sh ${FORCED}
fi
if ./uninstall-recorder.sh ${FORCED} && ./uninstall-hooks.sh ${FORCED}; then
    if [[ ${FORCED} -eq 1 ]]; then
        echo "Forced uninstalling..."
        rm -f /usr/bin/ekran_recorder
        rm -rf /var/log/.ekran/*
        rm -rf /etc/.ekran/*
        rm -rf /usr/lib/.ekran/*
        find /var/.ekran/ -not -name "internal" -delete 2>/dev/null
        rm -rf /var/.ekran/internal/*
        rm -f /etc/cron.hourly/ekran
    fi
else
    echo "Can't find uninstall-recorder.sh or uninstall-hooks.sh"
fi
./uninstall-service.sh ${FORCED}
if [[ $REMOVE_SETTINGS -eq 1 ]]; then
    rm -rf /etc/.ekran/*
fi

rm -- "$0"
FOLDERPATH="$(cd "$(dirname "$0")" && pwd)"
cd ~
rm -rf "$FOLDERPATH"

rm -f /tmp/SytecaMaintenance
