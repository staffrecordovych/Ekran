#!/bin/bash

function version { echo "$@" | awk -F. '{ printf("%d%03d%03d%03d\n", $1,$2,$3,$4); }'; }

function setup_logrotate {
    if [[ "$(uname)" == "Linux" ]]; then

        if [[ ! -f /var/log/.ekran/recorder.rotate.log ]]; then
            touch /var/log/.ekran/recorder.rotate.log
        fi
        chmod u=rw,g=,o= /var/log/.ekran/recorder.rotate.log

        if [[ -e /etc/logrotate.d/ekran ]]; then
            rm -f /etc/logrotate.d/ekran
        fi
        touch /etc/logrotate.d/ekran
        chmod 644 /etc/logrotate.d/ekran

        LOGROTATE_VERSION="`echo $(logrotate --version 2>&1) | sed 's/^.*[^0-9]\([0-9]*\.[0-9]*\.[0-9]*\).*$/\1/'`"

        # setup log rotation for hooks.log

        echo "/var/log/.ekran/hooks.log {" >> /etc/logrotate.d/ekran
        echo "  missingok" >> /etc/logrotate.d/ekran
        echo "  copytruncate" >> /etc/logrotate.d/ekran
        echo "  daily" >> /etc/logrotate.d/ekran
        echo "  size 50M" >> /etc/logrotate.d/ekran
        echo "  rotate 5" >> /etc/logrotate.d/ekran
        echo "  compress" >> /etc/logrotate.d/ekran
        echo "  nodateext" >> /etc/logrotate.d/ekran

        if [ $(version $LOGROTATE_VERSION) -ge $(version "3.8.0") ]; then
            echo "  su root root" >> /etc/logrotate.d/ekran
        fi
        echo "}" >> /etc/logrotate.d/ekran

        CRON_FILE=/etc/cron.hourly/ekran
        echo '#!/bin/bash' > $CRON_FILE
        echo 'logrotate /etc/logrotate.d/ekran >> /var/log/.ekran/logrotate.log 2>&1' >> $CRON_FILE
        chmod +x $CRON_FILE

        # setup log rotation for recorder*.log

        echo "/var/log/.ekran/recorder.rotate.log {" >> /etc/logrotate.d/ekran
        echo "  weekly"  >> /etc/logrotate.d/ekran
        echo "  missingok" >> /etc/logrotate.d/ekran
        echo "  copytruncate" >> /etc/logrotate.d/ekran
        echo "  rotate 0" >> /etc/logrotate.d/ekran
        echo "  postrotate" >> /etc/logrotate.d/ekran
        echo "       bash -c \"mkdir -p /var/log/.ekran/recorder_logs/ &&\\" >> /etc/logrotate.d/ekran
        echo "       find /var/log/.ekran/ -maxdepth 1 -name \\\"recorder_*.log.*\\\" -type f -mtime +14 -exec mv -t /var/log/.ekran/recorder_logs/ {} \; &>/dev/null &&\\" >> /etc/logrotate.d/ekran
        echo "       find /var/log/.ekran/ -maxdepth 1 -name \\\"recorder_*.log\\\" -type f -mtime +14 -exec mv -t /var/log/.ekran/recorder_logs/ {} \; &>/dev/null &&\\" >> /etc/logrotate.d/ekran
        echo "       tar -C /var/log/.ekran/recorder_logs -cf - . | gzip > /var/log/.ekran/recorder_logs.tar.gz &&\\" >> /etc/logrotate.d/ekran
        echo "       rm -rf /var/log/.ekran/recorder_logs\"" >> /etc/logrotate.d/ekran
        echo "  endscript" >> /etc/logrotate.d/ekran
        if [ $(version $LOGROTATE_VERSION) -ge $(version "3.8.0") ]; then
            echo "  su root root" >> /etc/logrotate.d/ekran
        fi
        echo "}" >> /etc/logrotate.d/ekran

        # setup log rotation for recorder_logs.tar.gz

        echo "/var/log/.ekran/recorder_logs.tar.gz {" >> /etc/logrotate.d/ekran
        echo "  missingok" >> /etc/logrotate.d/ekran
        echo "  weekly" >> /etc/logrotate.d/ekran
        echo "  nocompress" >> /etc/logrotate.d/ekran
        echo "  rotate 10" >> /etc/logrotate.d/ekran
        echo "  extension .tar.gz" >> /etc/logrotate.d/ekran

        if [ $(version $LOGROTATE_VERSION) -ge $(version "3.8.0") ]; then
            echo "  su root root" >> /etc/logrotate.d/ekran
        fi
        echo "}" >> /etc/logrotate.d/ekran

        # setup log rotation for LoginsLogouts.log

        echo "/var/log/.ekran/LoginsLogouts.log {" >> /etc/logrotate.d/ekran
        echo "  missingok" >> /etc/logrotate.d/ekran
        echo "  copytruncate" >> /etc/logrotate.d/ekran
        echo "  daily" >> /etc/logrotate.d/ekran
        echo "  size 50M" >> /etc/logrotate.d/ekran
        echo "  rotate 5" >> /etc/logrotate.d/ekran

        if [ $(version $LOGROTATE_VERSION) -ge $(version "3.8.0") ]; then
            echo "  su root root" >> /etc/logrotate.d/ekran
        fi
        echo "}" >> /etc/logrotate.d/ekran
    fi
}

setup_logrotate