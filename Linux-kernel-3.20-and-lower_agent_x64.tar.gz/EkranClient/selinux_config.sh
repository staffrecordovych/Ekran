#!/bin/bash

checkmodule -M -m -o fprintdpol.mod fprintdpol.te
semodule_package -m fprintdpol.mod -o fprintdpol.pp
semodule -i fprintdpol.pp

rm -f fprintdpol.mod
rm -f fprintdpol.pp
