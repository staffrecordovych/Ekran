#!/bin/bash -x
export SHELLOPTS

function getServicePIDs {
    if [[ "$(uname)" == "SunOS" ]]; then
        echo "$(ps -eo 'pid,comm,zone' | grep $(zonename) | grep EkranAgent | grep -v grep  | awk '{ print $1 }')"
    else
        echo "$(ps -eo 'pid,comm' | grep EkranAgent | grep -v grep | awk '{ print $1 }')"
    fi
}

function getWatchdogs {
    I=0
    for PID in $(getServicePIDs); do
        local AGENTPPID=`ps -o ppid= -fp $PID | awk '{ print $1 }'`
        local AGENTPPIDCMD=`ps -o cmd= $AGENTPPID`
        if echo "$AGENTPPIDCMD" | grep -q EkranAgent ; then
            AGENTARR["$I"]="$AGENTPPID"
            ((I++))
        fi
    done
}

LOG_FILE=/var/log/.ekran/update_log
exec >> $LOG_FILE 2>&1

LINE="====================="
printf "%s\n%s\n%s\n" $LINE "$(date)" $LINE

chmod u=rw,g=,o= $LOG_FILE

function killWatchDogs {
    getWatchdogs
    for PID in ${AGENTARR[*]}; do
        if ps -p $PID > /dev/null; then
            echo "Killing : $PID"
            # need to kill forcibly to cover case of buggy watchdogs (v. 6.5.339)
            kill -SIGKILL ${PID} &>/dev/null
        fi
    done
}


DIR=$1

function IsItNotSeAgent {
    [ ! -f $DIR/plugin.tar.gz ]
}

if [[ "$(uname)" == "Linux" ]]; then
   echo $$ > /sys/fs/cgroup/systemd/tasks
fi

INSTALL_DIR="`echo -n $(grep InstallDir /etc/.ekran/settings.xml | sed "s/<\/*InstallDir>//g")`"

# had to make this fix (killWatchDogs) due to AC-22947 (buggy watchdog in some Agent versions)
killWatchDogs
${INSTALL_DIR}/stop.sh

if [ "$(uname)" == "Linux" ] && [ "$(uname -m)" == "x86_64" ] && IsItNotSeAgent; then
    source .commonStuff
    SaveLinksBeforeExciting
fi

${INSTALL_DIR}/stop-offlinePoolManager.sh

if [ "$(uname)" == "Linux" ] && [ "$(uname -m)" == "x86_64" ] && IsItNotSeAgent; then
    RestoreLinksIfDeleted
fi

# give some time for EkranAgent to stop
sleep 1

# since we had to kill watchdog forcibly, the lock might not be released correctly
# so, to be sure, need to remove the file
# fix of AC-24289
AGENT_LOCK_FILE="/var/.ekran/Agent.lock"
if [[ -e "$AGENT_LOCK_FILE" ]]; then
    echo "Removing agent lock"
    rm -f "$AGENT_LOCK_FILE"
fi

# dump running EkranAgent processes to log
echo "Running EkranAgent processes"
for PID in $(getServicePIDs); do
    echo "$(ps -ef | grep ${PID})"
    kill -SIGKILL ${PID} &>/dev/null
done

mkdir -p /var/log/.ekran/

FULL_PATH="${DIR}/"
if [ "$(uname)" == "Linux" ] && [ "$(uname -m)" == "x86_64" ] && IsItNotSeAgent; then
    FULL_PATH=${FULL_PATH}"EkranClient/"
fi
FULL_PATH=${FULL_PATH}"install.sh"

OLD_VERSION=$(sed -n 's,<AgentVersion>\(.*\)</AgentVersion>,\1,p' /etc/.ekran/settings.xml)
NEW_VERSION=$(sed -n 's,VERSION=\(.*\),\1,p' $FULL_PATH)
printf "\nStarting update from version %s to %s\n\n" $OLD_VERSION $NEW_VERSION

export UPDATE=1
(exec bash -c $FULL_PATH &)
