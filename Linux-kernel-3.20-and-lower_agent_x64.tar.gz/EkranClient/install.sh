#!/bin/bash
cd "$(dirname $BASH_SOURCE[0])"
umask 02

touch /tmp/SytecaMaintenance

INSTALL_DIR="/opt/.Ekran"
REMOTE_HOST=""
REMOTE_PORT=""
SYSTEM="linux"
VERSION="7.20.643"
ARCH="x64"
WITH_X11=""
TENANT_KEY=""
FORCE_INSTALL=""
FORCE_INSTALL_ARG_NAME="-force"
X11_ARG_NAME="-withX11"
WAYLAND_ARG_NAME="-withWayland"
UI_ARG_NAME="-withUI"
TENANT_KEY_ARG_NAME="-tenantKey"
SKIP_LINKAGE_CHECKS=0
IS_HOOKS_TEST_MODE=""
HOOKS_TEST_KEY_ARG_NAME="-test_hooks"
INPUT_ARGS_COUNT=$#
INPUT_ARGS=("$@")
CURRENT_DIR="$(pwd)"

LIST_OF_FILES=""

if [[ $EUID -ne 0 ]]; then
    echo "You must be a root user"
    exit 1
fi

function usage {
    echo "./install.sh <host> <port> <dir?> <-withX11?> <-withWayland?> <-withUI?> <-tenantKey?> <-test_hooks?> <-force?>"
}

function unpack {
    PACKAGE_NAME=$1
    echo "Unpacking ${PACKAGE_NAME}"
    cd "$CURRENT_DIR"
    mkdir -p "./${PACKAGE_NAME}" && cd "./${PACKAGE_NAME}"
    cp "../${PACKAGE_NAME}.tar.gz" .

    if ! gzip -fd "./${PACKAGE_NAME}.tar.gz"; then
        echo "Error while decompressing ${PACKAGE_NAME}.tar.gz"
        abort_installation
    fi

    if ! tar -xf "./${PACKAGE_NAME}.tar"; then 
        echo "Error while trying to untar ${PACKAGE_NAME}.tar"
        abort_installation
    fi
    
    rm "./${PACKAGE_NAME}.tar"

    cd "$CURRENT_DIR"
    LIST_OF_FILES+=$(find ./ -type f -exec basename {} \;)
}

function install {
    PACKAGE_NAME=$1
    echo "Installing ${PACKAGE_NAME}"
    cd "$CURRENT_DIR/${PACKAGE_NAME}"
    if [[ "${PACKAGE_NAME}" == "service" ]]; then
        "./install-${PACKAGE_NAME}.sh" "$REMOTE_HOST" "$REMOTE_PORT" "$INSTALL_DIR" "$TENANT_KEY" "$OLD_INSTALL_DIR"
    else
        "./install-${PACKAGE_NAME}.sh" "$INSTALL_DIR" "$OLD_INSTALL_DIR"
    fi
    cd ..
    rm -rf "${PACKAGE_NAME}"
    return 0
}

function abort_installation {
    echo "Aborting installation... "

    cd ${INSTALL_DIR}

    local needToRemoveLibs=YES
    # in case of update we need to start previous agent
    if [[ -f ${OLD_INSTALL_DIR}/start.sh ]]; then
        ${OLD_INSTALL_DIR}/start.sh
        needToRemoveLibs=NO
    fi
    # do not remove this logic even though standalone offline pool manager no longer exists
    if [[ -f ${OLD_INSTALL_DIR}/start-offlinePoolManager.sh ]]; then
        ${OLD_INSTALL_DIR}/start-offlinePoolManager.sh
        needToRemoveLibs=NO
    fi

    if [ $needToRemoveLibs == YES ]; then
        rm -rf /usr/lib/.ekran/
    fi
    exit 1
}

function is_correct_package {
    local actualSystem="$(uname)"

    case $actualSystem in
        Linux)
            if [[ $SYSTEM != "linux" ]]; then
                echo "This installation package is intended for a different operating system."
                exit 1
            fi

            if [[ $ARCH == "x64" && $(uname -m) != "x86_64" ]]; then
                echo "This installation package is intended for a different processor architecture."
                exit 1
            fi

            if [[ $ARCH == "x86" && $(uname -m) != "i686" ]]; then
                echo "This installation package is intended for a different processor architecture."
                exit 1
            fi
            ;;
        SunOS)
            if [[ $SYSTEM != "solaris" ]]; then
                echo "This installation package is intended for a different operating system."
                exit 1
            fi

            if [[ $ARCH == "x64" && $(uname -m) != "i86pc" ]]; then
                echo "This installation package is intended for a different processor architecture."
                exit 1
            fi

            if [[ $ARCH != "x64" && $(uname -m) == "i86pc" ]]; then
                echo "This installation package is intended for a different processor architecture."
                exit 1
            fi
            ;;
        AIX)
            if [[ $SYSTEM != "aix" ]]; then
                echo "This installation package is intended for a different operating system."
                exit 1
            fi
            ;;
    esac
}

function copy_libs {
    local LIBDIR=/usr/lib/.ekran
    mkdir -p $LIBDIR
    chmod a+rx "$1"/*
    mv "$1"/* $LIBDIR/
}

function check_recorder {
    echo "Checking work of recorder"
    if [[ "$(uname)" == "Linux" ]]; then
        # we need to put all the lib dependencies in /usr/lib/.ekran before testing recorder
        # to avoid the error due to different sys lib versions on the build and the target platforms 
        copy_libs "$CURRENT_DIR"/recorder/libs/
	      if [ "$(uname -m)" == "x86_64" ] || [ "$(uname -m)" == "i686" ]; then
            "$CURRENT_DIR"/recorder/recorder -V -c "date" -f -q
        elif [[ "$(uname -m)" == "ppc64le" ]]; then
            LD_LIBRARY_PATH="$CURRENT_DIR"/recorder/libs "$CURRENT_DIR"/recorder/libs/ld64.so.2  "$CURRENT_DIR"/recorder/recorder -V -c "date" -f -q
        else
            echo "Not supported architecture"
            abort_installation
        fi
    else
        if [[ "$(uname)" == "AIX" && "$SKIP_LINKAGE_CHECKS" != "1" ]]; then
            RECORDER_DUMP="$(dump -H recorder/recorder)"
            if ! grep  "/usr/lib/.ekran.*libgcc_s.a" <<< "$RECORDER_DUMP" > /dev/null \
            || ! grep  "/usr/lib/.ekran.*libstdc++.a" <<< "$RECORDER_DUMP" > /dev/null;then
                echo Recorder was linked improperly
                dump -H recorder/recorder
                csum -h MD5 recorder/recorder
                abort_installation
            fi

            EKRANSR_DUMP="$(dump -H recorder/ekransr)"
            if ! grep  "/usr/lib/.ekran.*libgcc_s.a" <<< "$EKRANSR_DUMP" > /dev/null \
            || grep "libstdc++.a" <<< "$EKRANSR_DUMP" > /dev/null;then
                echo ekransr was linked improperly
                dump -H recorder/ekransr
                csum -h MD5 recorder/ekransr
                abort_installation
            fi
        fi

        LD_LIBRARY_PATH="$CURRENT_DIR"/recorder/libs "$CURRENT_DIR"/recorder/recorder -V -c "date" -f -q
    fi
    RES=$?
    if [ $RES -ne 0 ]; then
        echo $RES
        echo "Looks like recorder is missing some dependecies to start..."
        abort_installation
    fi
}

function check_recorder_postinstall {
    RECORDER_TO_RUN=$(ls -t $INSTALL_DIR/ekran_recorder* | head -n1)
    if [[ "$(uname)" == SunOS ]]; then
        LD_LIBRARY_PATH="/usr/lib/.ekran/:$LD_LIBRARY_PATH" "$RECORDER_TO_RUN" -V -c "date" -f -q 2>/tmp/recorderError
    else
        "$RECORDER_TO_RUN" -V -c "date" -f -q 2>/tmp/recorderError
    fi
    RES=$?

    if grep settings.xml /tmp/recorderError | grep expected; then
        rm -f /var/.ekran/internal/rescue_mode
        RES=0
    fi

    if [ $RES -ne 0 ]; then
        echo $RES
        echo "Something went wrong during the installation. Installation will not be completed."
        echo Error:
        cat /tmp/recorderError && rm -f /tmp/recorderError

        if [[  $UPDATE -eq 1 ]];then
            ldd "$RECORDER_TO_RUN"
        fi

        if [[ "$(uname)" == "Linux" ]]; then
            if [[ -e /etc/ld.so.preload ]]; then
                sed -i "/\.ekran\/.*libhook/d" /etc/ld.so.preload
                sed -i "/\.ekran\/.*libX11hook/d" /etc/ld.so.preload
            fi
        fi

        if [[ "$(uname)" == "AIX" ]]; then
            unset LDR_PRELOAD
            unset LDR_PRELOAD64
            sed "/LDR_PRELOAD/d" /etc/profile > /tmp/profile
            cp /tmp/profile /etc/profile
        fi

        if [[ "$(uname)" == "SunOS" ]]; then
            unset LD_PRELOAD_32 LD_PRELOAD_64
            crle -u -e LD_PRELOAD_32= -e LD_PRELOAD_64=
            crle -u -e LD_PRELOAD_32= -e LD_PRELOAD_64= -64

            echo "$(sed "/LD_PRELOAD/d" /etc/profile)" > /etc/profile
        fi
        
        touch /var/.ekran/internal/rescue_mode
        exit 1
    fi
    rm -f /tmp/recorderError
}

function check_hooks {
    echo "Checking work of hooks"
    
    LIBHOOK_SYMLINK="temp_libhook_symlink.so"
    ln -s "$CURRENT_DIR" "$LIBHOOK_SYMLINK"
    trap "rm -f $LIBHOOK_SYMLINK" EXIT

    if [[ "$(uname)" == "Linux" ]]; then
        # during update there can be problems if two our hook libraries (old and new) are loaded into the testing tool
        # so, temporary renaming ld.so.preload file to avoid it 
        if [[ -f /etc/ld.so.preload ]]; then
            mv /etc/ld.so.preload /etc/_ld.so.preload
        fi

	      if [[ "$(uname -m)" == "x86_64" ]]; then
            LIB_FILENAME="libhook64.so"
        elif [[ "$(uname -m)" == "ppc64le" ]]; then
            LIB_FILENAME="libhook64.so"
        elif [[ "$(uname -m)" == "i686" ]]; then
            LIB_FILENAME="libhook32.so"
        else
            echo "Not supported architecture"
            abort_installation
        fi

        LD_PRELOAD="$LIBHOOK_SYMLINK/hooks/$LIB_FILENAME"  "$LIBHOOK_SYMLINK/hooks/HooksTestingTool"

        RES32=$? 
        RES64=0
        if [[ -f /etc/_ld.so.preload ]]; then
            mv /etc/_ld.so.preload /etc/ld.so.preload
        fi
    elif [[ "$(uname)" == "SunOS" ]]; then
        LD_PRELOAD_32="$LIBHOOK_SYMLINK/hooks/libhook32.so" "$LIBHOOK_SYMLINK/hooks/HooksTestingTool"
        RES32=$?
        LD_PRELOAD_64="$LIBHOOK_SYMLINK/hooks/libhook64.so" "$LIBHOOK_SYMLINK/hooks/HooksTestingTool"
        RES64=$?
    else
        HOOKS32_DUMP="$(dump -H hooks/libhook32.so)"
        if [[ "$SKIP_LINKAGE_CHECKS" != "1" ]]; then
            if ! grep  "/usr/lib/.ekran.*libgcc_s.a" <<< "$HOOKS32_DUMP" > /dev/null; then
                echo Hooks32 was linked improperly
                dump -H hooks/libhook32.so
                csum -h MD5 hooks/libhook32.so
                abort_installation
            fi
        fi

        LD_LIBRARY_PATH="$CURRENT_DIR"/hooks/libs LDR_PRELOAD="$CURRENT_DIR"/hooks/libhook32.so "$CURRENT_DIR"/hooks/HooksTestingTool
        RES32=$?
        LD_LIBRARY_PATH="$CURRENT_DIR"/hooks/libs LDR_PRELOAD64=:"$CURRENT_DIR"/hooks/libhook64.so "$CURRENT_DIR"/hooks/HooksTestingTool
        RES64=$?
    fi

    if [[ $RES64 -ne 0 || $RES32 -ne 0 || ! -z $IS_HOOKS_TEST_MODE ]]; then
        echo "Looks like there will be possible problems with hooks after installations..."
        abort_installation
    fi
}

function check_dependencies {
    echo "Checking dependencies"

    if [[ -f /etc/ld.so.preload ]]; then
        local preloaded=$(grep -v "lib.*hook" /etc/ld.so.preload)
        if [[ "${preloaded}" ]]; then
            echo "/etc/ld.so.preload contains unexpected files. The following files are currently preloaded:"
            echo "${preloaded}"

            if [[ ! -f $OLD_INSTALL_DIR/uninstall-service.sh ]]; then
                echo "Conflicting libraries inside the \"ld.so.preload\" file might render your system unusable. Therefore installation will be aborted to avoid any issues."
                echo "Warning! Use of the \"$FORCE_INSTALL_ARG_NAME\" flag to proceed with installation is at your own risk."
                abort_installation
            fi
        fi
    fi

    if [[ "$(uname)" == "Linux" && ("$(uname -m)" == "x86_64" || "$(uname -m)" == "i686") ]]; then
        local ldd_results=$(ldd "$CURRENT_DIR"/recorder/recorder)

        IFS=$'\n' read -ra ldd_results_split -d $'\0' <<< "$ldd_results"

        # Probably it's a bad idea to abort_installation here, however we should warn about this
        for line in "${ldd_results_split[@]}"; do
            if [[ "$line" != *"/usr/lib/.ekran/"* && \
                  "$line" != *"ld"* && \
                  "$line" != *"libdl"* && \
                  "$line" != *"linux-vdso"* && \
                  "$line" != *"needs"* && \
                  "$line" != *"unix"* ]]; then
                # xargs here simply trims the line
                echo "Unexpected or unmet recorder dependency: \"$(echo "$line" | xargs)\""
            fi
        done
    fi
}

function check_permissions() {
    if [[ "$(uname)" == "Linux" ]]; then
        cd ${INSTALL_DIR}
        local parent="$(pwd)"    

        while true; do
            local permissions="$(stat -c "%a" "${parent}")"
            # Note that permissions are converted to decimal here
            if [ $((8#$permissions & 73)) -ne "73" ]; then # --x--x--x
                echo "There might be problems with installation due to insufficient permissions for \"${parent}\"."
                echo "All parents of ${INSTALL_DIR} should have at least --x--x--x bits set"
                abort_installation
            fi
            cd ..
            local child="$(pwd)"
            if [[ "${child}" = "${parent}" ]]; then 
                break
            fi
            parent="${child}"
        done
        
        cd "$CURRENT_DIR"
    fi
}

function good_to_install {
    if [[ -z "$FORCE_INSTALL" ]]; then

        if [[ "$(uname)" == "AIX" ]]; then
            mkdir -p /usr/lib/.ekran
            mv recorder/libs/lib{gcc_s,stdc++}.a /usr/lib/.ekran
        fi
        check_permissions
        check_recorder
        check_dependencies
        check_hooks
    fi
}

function run_postinstall_checks {
    if [[ -z "$FORCE_INSTALL" ]]; then
        echo -n "Running post-installation checks... "
        check_recorder_postinstall
        echo "Success"
    fi
}

function create_folders_and_files {
    # create folder for logs if not exists
    mkdir -p /var/log/.ekran
    mkdir -p /var/.ekran/internal/functions
    mkdir -p /var/.ekran/internal/recorders

    chmod 777 /var/log/.ekran
    chmod +t /var/log/.ekran
    chmod 755 /var/.ekran
    chmod 777 /var/.ekran/internal
    chmod 666 "/var/.ekran/internal/GuiRecorder*" &> /dev/null
    chmod -R 777 /var/.ekran/internal/functions
    chmod -R 777 /var/.ekran/internal/recorders
    chmod +t /var/.ekran/internal/
    chmod +t /var/.ekran/internal/recorders
    chmod +t /var/.ekran/internal/functions

    if [ ! -w /var/.ekran/internal/functions ] || \
       [ ! -w /var/.ekran/internal/recorders ] || \
       [ ! -w /var/log/.ekran/ ]; then

        echo "Failed to create required directories"
        abort_installation
    fi

    if [[ ! -f /var/.ekran/internal/sessions_count ]]; then
        echo -n 0 > /var/.ekran/internal/sessions_count
        chmod u=rw,g=r,o=r /var/.ekran/internal/sessions_count
    fi

    if [[ -e "/var/.ekran/functions" ]]; then
        chmod +t /var/.ekran/recorders
        chmod +t /var/.ekran/functions
    fi

    # implementation detail, was not deleted after its usage in legacy clients
    rm -f /var/log/.ekran/getenv.tar.gz
}

function prepare_settings {
    mkdir -p /etc/.ekran
    if [[ -f "/etc/.ekran/settings.xml" ]]; then
        mv /etc/.ekran/settings.xml /etc/.ekran/settings.xml.backup
    fi
    cp "$CURRENT_DIR/service/settings.xml" /etc/.ekran/settings.xml
    if [[ -e "$CURRENT_DIR/settings.ini" ]]; then
        cp "$CURRENT_DIR/settings.ini" /etc/.ekran/settings.ini
    fi
    echo "<RemoteHost>$REMOTE_HOST</RemoteHost>" >> /etc/.ekran/settings.xml
    echo "<RemotePort>$REMOTE_PORT</RemotePort>" >> /etc/.ekran/settings.xml
    echo "<InstallDir>$INSTALL_DIR</InstallDir>" >> /etc/.ekran/settings.xml
    echo "<TenantKey>$TENANT_KEY</TenantKey>" >> /etc/.ekran/settings.xml

    if [[ -f "/etc/.ekran/settings.xml.backup" ]]; then
        local old_hostname_string="$(grep -e "<RemoteHost>.*</RemoteHost>" /etc/.ekran/settings.xml.backup 2>/dev/null)"
        local new_hostname_string="$(grep -e "<RemoteHost>.*</RemoteHost>" /etc/.ekran/settings.xml 2>/dev/null)"

        if [[ "$old_hostname_string" == "$new_hostname_string" ]]; then
            local path_to_grep="grep"
            if [[ "$(uname)" == "SunOS" && -e "/usr/xpg4/bin/grep" ]]; then
                path_to_grep="/usr/xpg4/bin/grep"
            fi

            parameters_to_append=$( \
                "$path_to_grep" -v -e "xml version="\
                        -e "<AgentVersion>.*</AgentVersion>" \
                        -e "<Watchdog>.*</Watchdog>" \
                        -e "<GuiWatchdog>.*</GuiWatchdog>" \
                        -e "<RemoteHost>.*</RemoteHost>" \
                        -e "<RemotePort>.*</RemotePort>" \
                        -e "<InstallDir>.*</InstallDir>" \
                        -e "TenantKey" /etc/.ekran/settings.xml.backup \
            )
            echo "${parameters_to_append}" >> /etc/.ekran/settings.xml
        fi

        rm -f /etc/.ekran/settings.xml.backup
    fi

    if [ "$(uname)" == "Linux" ]; then
        function RemoveCertIfReinstallingAndDifferentTargetServer {
            if [[ $UPDATE -ne 1 ]] && [[ -d  $OLD_INSTALL_DIR/connection-certificates/ ]]; then
                local OLD_CERT=$OLD_INSTALL_DIR/connection-certificates/Client-CA.crt
                local NEW_CERT=service/connection-certificates/Client-CA.crt
                if [[ $(md5sum "$OLD_CERT" | awk '{print $1}') != $(md5sum "$NEW_CERT" | awk '{print $1}') ]];then
                    sed -i '/<EncryptionCertificate>.*<\/EncryptionCertificate>/d' /etc/.ekran/settings.xml
                fi
            fi
        }
        RemoveCertIfReinstallingAndDifferentTargetServer
    fi
}

function parse_input_args {
    local positionalIndex=0
    for (( i=0; i<$INPUT_ARGS_COUNT; ++i)); do
    CUR_ARG="${INPUT_ARGS[$i]}"
    case "$CUR_ARG" in
        # named arguments
        "$X11_ARG_NAME")
        WITH_X11=1
        ;;

        "$WAYLAND_ARG_NAME")
        WITH_X11=1
        ;;

        "$UI_ARG_NAME")
        WITH_X11=1
        ;;

        "$FORCE_INSTALL_ARG_NAME")
        FORCE_INSTALL=1
        ;;

        "$TENANT_KEY_ARG_NAME")
        j=$((i+1))
        TENANT_KEY="${INPUT_ARGS[j]}"
        if [[ "$TENANT_KEY" == "$X11_ARG_NAME" ]]; then
            echo "The Tenant Key parameter cannot be empty. Please make sure the Tenant Key is entered correctly."
            exit 1
        fi

        if [[ "$TENANT_KEY" == *['!'\<\>\&\'\"]* ]]; then
            echo "The Tenant Key parameter contains invalid characters. Please make sure the Tenant Key is entered correctly."
            exit 1
        elif [[ -z $TENANT_KEY ]]; then
            echo "The Tenant Key parameter cannot be empty. Please make sure the Tenant Key is entered correctly."
            exit 1
        fi
        i=$j
        ;;

        "$HOOKS_TEST_KEY_ARG_NAME")
        IS_HOOKS_TEST_MODE=1
        ;;

        -*|--*=) # unsupported flags
        usage
        exit 1
        ;;

        *) # positional arguments
        case $positionalIndex in
            0)
                REMOTE_HOST="$CUR_ARG"
            ;;

            1)
                REMOTE_PORT="$CUR_ARG"
            ;;

            2)
                INSTALL_DIR="$CUR_ARG"
            ;;
            
            *)
                echo "Unexpected argument: $CUR_ARG"
            ;;
        esac
        positionalIndex=$((positionalIndex+1))
        ;;
    esac
    done
}

function cleanup_legacy_libs {
    LIST_OF_FILES=$(echo $LIST_OF_FILES | tr ' ' '\n' | sort | uniq | tr '\n' ' ')

    find "/usr/lib/.ekran" -type f | while IFS= read -r file; do
        if echo $LIST_OF_FILES | grep -q "$(basename "$file")"; then
            continue;
        fi

        if echo "$(basename "$file")" | grep -q "hook"; then
            continue
        fi

        echo "Cleaning up $file"
        rm -f "$file"
    done
}

function IsInternalFolderDoesntExistOrEmptyOrConsistOfDBfilesOnly {
      local DIR=/var/.ekran/internal/
      [ ! -d $DIR ] && return
      [ -z "$(find $DIR  ! -name "*EkranOfflinePool.dat*" | sed -e "1d")" ]
}

is_correct_package

# Checking for legacy agent (before 6.1)
# Custom directory not supported, so looking at /opt/.Ekran
if [[ -e "${INSTALL_DIR}/settings.xml" ]]; then
    mkdir -p /etc/.ekran/ /var/.ekran/
    cp "${INSTALL_DIR}/settings.xml" /etc/.ekran/settings.xml
    E_SUID_COUNTER="`echo -n $(grep SUIDCounter /etc/.ekran/settings.xml | sed "s/<\/*SUIDCounter>//g")`"
    if [[ -n "$E_SUID_COUNTER" ]]; then
        echo "$E_SUID_COUNTER" > /var/.ekran/ekran_recorder_suid_counter
    fi
    if [[ -e "${INSTALL_DIR}/OfflinePool.dat" ]]; then
        mv "${INSTALL_DIR}/OfflinePool.dat" /var/.ekran/internal/EkranOfflinePool.dat
    fi
    "${INSTALL_DIR}/uninstall.sh"
    rm -f "${INSTALL_DIR}/settings.xml"
fi

if [[ -e /etc/.ekran/settings.xml ]]; then
    E_INSTALL_DIR="`echo -n $(grep InstallDir /etc/.ekran/settings.xml | sed "s/<\/*InstallDir>//g")`"
    E_REMOTE_HOST="`echo -n $(grep RemoteHost /etc/.ekran/settings.xml | sed "s/<\/*RemoteHost>//g")`"
    E_REMOTE_PORT="`echo -n $(grep RemotePort /etc/.ekran/settings.xml | sed "s/<\/*RemotePort>//g")`"
    E_TENANT_KEY="`echo -n $(grep TenantKey /etc/.ekran/settings.xml | sed "s|<\/*TenantKey\/*>||g")`"
    if [[ -n "$E_REMOTE_HOST" ]]; then
        REMOTE_HOST="$E_REMOTE_HOST";
    fi
    if [[ -n "$E_REMOTE_PORT" ]]; then
        REMOTE_PORT="$E_REMOTE_PORT";
    fi
    if [[ -n "$E_INSTALL_DIR" ]]; then
        INSTALL_DIR="$E_INSTALL_DIR";
        OLD_INSTALL_DIR="$E_INSTALL_DIR";
    fi
    if [[ -n "$E_TENANT_KEY" ]]; then
        TENANT_KEY="$E_TENANT_KEY";
    fi
    if [[ -e "${INSTALL_DIR}/uninstall-recorderGUI.sh" ]]; then
        WITH_X11="1";
    fi
fi

if [[ -e ./connection ]]; then
    REMOTE_HOST="`cat ./connection`"
    REMOTE_PORT="9447"
fi

parse_input_args

if [[ -z "$REMOTE_HOST" ]] || [[ -z "$REMOTE_PORT" ]]; then
    usage
    exit 1
fi

if [[ ! -z "$FORCE_INSTALL" ]]; then
    echo "Forced installation."
fi

if [[ -e ./selinux_config.sh ]]; then
    if which semodule_package &> /dev/null; then
        ./selinux_config.sh
    fi
fi

if [[ ! -d "$INSTALL_DIR" ]]; then
    if [[ -f "$INSTALL_DIR" ]]; then
        rm -rf "$INSTALL_DIR"
    fi
    echo "Creating $INSTALL_DIR..."
    mkdir -p "$INSTALL_DIR"
    chmod -R 755 "$INSTALL_DIR/"
fi

if [ ! -w $INSTALL_DIR ]; then
    echo "Failed to create $INSTALL_DIR"
    exit 1
fi

# This will expand $INSTALL_DIR in case its relative
INSTALL_DIR=$(cd "$INSTALL_DIR" && pwd)

echo "Installing agent into $INSTALL_DIR..."

# Space requirement is given in KiB; shouldn't use MiB because -m flag for df isn't supported on SunOS
DISK_SPACE_REQUIRED=524288
DISK_SPACE_AVAILABLE=$(df -k -P "${INSTALL_DIR}" 2> /dev/null | tail -1 | awk '{print $4}')
if [ "$DISK_SPACE_AVAILABLE" -lt "$DISK_SPACE_REQUIRED" ]; then
    echo "Not enough disk space for installation. Need at least $((DISK_SPACE_REQUIRED / 1024)) MiB."
    exit 1
fi

unpack "recorder"
unpack "hooks"
unpack "service"

IS_UPDATE_FROM_OLD=""
if [[ -n $INSTALL_DIR ]] && [[ -f $INSTALL_DIR/uninstall-service.sh ]] && IsInternalFolderDoesntExistOrEmptyOrConsistOfDBfilesOnly; then
    IS_UPDATE_FROM_OLD=1
fi

create_folders_and_files

# just for testing
# to be able to test broken update
if [[ -e /tmp/ekran_test_broken_update ]]; then
    echo "Testing mode: emulating broken update"
    abort_installation
fi

prepare_settings

good_to_install

cp "./.commonStuff" "$INSTALL_DIR/"

# Get rid of standalone offline pool manager when updating from older version
if [[ -n "$OLD_INSTALL_DIR" ]]; then
    if [[ -f "$OLD_INSTALL_DIR"/stop-offlinePoolManager.sh ]]; then
        "$OLD_INSTALL_DIR"/stop-offlinePoolManager.sh
    fi

    if [[ -f "$OLD_INSTALL_DIR"/uninstall-offlinePoolManager.sh ]]; then
        echo "Found offlinePoolManager in $OLD_INSTALL_DIR. Uninstalling first..."
        "$OLD_INSTALL_DIR"/uninstall-offlinePoolManager.sh
    fi
fi

install "recorder"
if [[ "$(uname)" == "Linux" && ! -z $WITH_X11 ]]; then
    unpack "recorderGUI"
    install "recorderGUI"
fi
install "service"
install "hooks"

#don't move this echo before install "recorderGUI"
if [[ $UPDATE -eq 1 && "$(uname)" == "Linux" && -n $WITH_X11 ]]; then
    if ! grep libX11hook /etc/ld.so.preload; then
        echo "/usr/lib/.ekran/\$LIB/libX11hook.so" >> /etc/ld.so.preload
    fi
fi

cleanup_legacy_libs

if command -v restorecon &>/dev/null ; then
    restorecon -R /usr/lib/.ekran/ >> /dev/null 2>&1
fi

# TODO: there will be a similar fragment that also temporarily unpacks service.tar.gz after merges, fix duplication when merging
if [[ "$(uname)" == "Linux" ]] && ! ls /usr/lib/.ekran/libsqlite3.so &> /dev/null; then
    mkdir "$CURRENT_DIR"/temp
    tar -xf "$CURRENT_DIR/service.tar.gz" -C "$CURRENT_DIR"/temp/
    mv "$CURRENT_DIR"/temp/libs/libsqlite3.so /usr/lib/.ekran/
    rm -r "$CURRENT_DIR"/temp/
fi

if [ -f /etc/debian_version ]; then
    LIB32_DIR="/usr/lib/.ekran/lib32"
else
    LIB32_DIR="/usr/lib/.ekran/lib"
fi

if [[ "$(uname)" == "Linux" && $(uname -m) == x86_64 ]] && ! ls $LIB32_DIR/libhook.so &> /dev/null; then
    mkdir "$CURRENT_DIR"/temp
    tar -xf "$CURRENT_DIR/hooks.tar.gz" -C "$CURRENT_DIR"/temp/
    mv "$CURRENT_DIR"/temp/libhook32.so $LIB32_DIR/libhook.so
    rm -r "$CURRENT_DIR"/temp/
fi

if [[ "$(uname)" == "Linux" && $(uname -m) == x86_64 && -n $WITH_X11 ]] && ! ls $LIB32_DIR/libX11hook.so &> /dev/null; then
    mkdir "$CURRENT_DIR"/temp
    tar -xf "$CURRENT_DIR/recorderGUI.tar.gz" -C "$CURRENT_DIR"/temp/
    mv "$CURRENT_DIR"/temp/libs/libX11hook32.so $LIB32_DIR/libX11hook.so
    rm -r "$CURRENT_DIR"/temp/
fi

if [ ! "$INSTALL_DIR" -ef "$OLD_INSTALL_DIR" ]; then
    rm -f "$OLD_INSTALL_DIR/getenv.sh"
    rm -f "$OLD_INSTALL_DIR/uninstall.sh"
    # we have to do this after all separate components get uninstalled as their uninstallers use this script
    rm -f "$OLD_INSTALL_DIR/.commonStuff"
fi

cp "./getenv.sh" "$INSTALL_DIR/"
cp "./uninstall.sh" "$INSTALL_DIR/"

chmod 755 /etc/.ekran
chmod 644 /etc/.ekran/settings.xml
chmod 755 /usr/bin/ekran_recorder
chmod -R 755 /usr/lib/.ekran

if [[ ! -z $IS_UPDATE_FROM_OLD ]]; then 
    # for backward compatibility with old paths
    echo "Creating links."
    ln -s /var/.ekran/internal/OfflinePoolManager.socket /var/.ekran/OfflinePoolManager.socket
    ln -s /var/.ekran/internal/actions.socket /var/.ekran/actions.socket
    chmod 666 /var/.ekran/OfflinePoolManager.socket
    chmod 666 /var/.ekran/actions.socket
    if [[ -f /var/.ekran/Agent.socket ]]; then
        chmod 666 /var/.ekran/Agent.socket
    fi
    if [[ -f /var/.ekran/secondaryAuth.socket ]]; then
        chmod 666 /var/.ekran/secondaryAuth.socket
    fi
fi

if [[ -f /var/.ekran/Agent.lock ]]; then
    chmod 644 /var/.ekran/Agent.lock
fi
if [[ -f /var/.ekran/icon.bmp ]]; then
    chmod 644 /var/.ekran/icon.bmp
fi

if [[ "$(uname)" == "Linux" ]]; then
    "./configure_logrotate.sh"
fi

sleep 1
run_postinstall_checks

if [[ ! -z ${WITH_X11} && "$(uname)" == "Linux" ]]; then
    echo "Please log out and log in again to start monitoring the UI sessions."
fi

if command -v sestatus &>/dev/null ; then
    if sestatus | grep -iq disabled; then
        echo "SELinux is disabled. Filesystem relabeling will occur upon re-enabling it."
        touch /.autorelabel
    fi
fi

rm -f /tmp/SytecaMaintenance
