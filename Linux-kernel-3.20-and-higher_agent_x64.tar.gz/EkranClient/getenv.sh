#!/bin/bash

# Get current dir
CURRENT_DIR=$(cd "$(dirname ${BASH_SOURCE[0]})" && pwd)

SETTINGS_FILE="/etc/.ekran/settings.xml"
LOGS_DIR="/var/log/.ekran"

ARCHIVE_NAME=`uname`"_getenv_"`date +"%y_%m_%d_%H_%M_%S"`
MOVE_TO=""

if [ ! -z "$1" ]; then
    ARCHIVE_NAME=$(basename "$1")
    if [[ "${ARCHIVE_NAME}" == *"tar.gz" ]]; then
        ARCHIVE_NAME=${ARCHIVE_NAME%".tar.gz"}
    fi
    MOVE_TO=$(dirname "$1")
    MOVE_TO="${MOVE_TO}/"
fi

WRN_COLOR=$'\e[1;33m'
ERR_COLOR=$'\e[1;31m'
NO_COLOR=$'\033[0m'

SILENT=0
echo "" > ./getenv.log
function LOG()
{
    if [[ SILENT -eq 0 ]]; then
        echo "$1$2 "`date +%D_%H:%M:%S`" : $3$NO_COLOR"
        echo "$1$2 "`date +%D_%H:%M:%S`" : $3$NO_COLOR" >> getenv.log
    fi
}
function LOG_INFO()
{
    LOG "$NO_COLOR" "[INF]" "$1"
}
function LOG_WARN()
{
    LOG "$WRN_COLOR" "[WRN]" "$1"
}
function LOG_ERROR()
{
    LOG "$ERR_COLOR" "[ERR]" "$1"
}

# Check root user
function IsRoot()
{
    if [[ $EUID -ne 0 ]]; then
        LOG_ERROR "You must be a root user"
        exit 1
    fi
}

function Usage()
{
    echo "getenv usage:
    -t; Ticket id
    -h; Show this help
    -s; Silent mode
    "
}

function BuildArchiveName()
{
    if [ -z "$TICKET_ID" ]; then
        LOG_WARN "No ticket id specified"
    else
        LOG_INFO "TICKET_ID="${TICKET_ID}
        ARCHIVE_NAME=$ARCHIVE_NAME"_ticket_${TICKET_ID}"
    fi
    LOG_INFO "ARCHIVE_NAME=${ARCHIVE_NAME}"
}

function InitiateTmpDirectory
{
    # Create temporary dir
    RES_DIR="/tmp/EkranGetenv"
    RES_DIR_LOGS="$RES_DIR/logs"
    RES_DIR_DEPS="$RES_DIR/dependencies"
    if [[ -d "${RES_DIR}" ]]; then
        rm -rf ${RES_DIR}
    fi
    
    mkdir -p ${RES_DIR}
    
    # Init subdirs
    if [[ -d "${RES_DIR}" ]]; then
        mkdir -p "${RES_DIR_LOGS}"
        mkdir -p "${RES_DIR_DEPS}"
    fi
}

function CollectLogs()
{
    # Logs collecting
    if [[ -d "${LOGS_DIR}" ]]; then
        cp -r "$LOGS_DIR/./" "$RES_DIR_LOGS/"
    else
        LOG_WARN "Can't open $LOGS_DIR"
    fi
}

function CollectDependencies()
{
    if [[ -d "$INSTALL_DIR" ]]; then
        LOG_INFO "found ${INSTALL_DIR}"
        for executable in ${INSTALL_DIR}/*; do
            if [[ -x "${executable}" ]]; then
                EXECUTABLE_BASE=`basename "${executable}"`
                if [[ "${EXECUTABLE_BASE}" != *".sh" ]]; then
                    EXECUTALBE_DEP_OUT="${RES_DIR_DEPS}/${EXECUTABLE_BASE}.txt"
                    file "${executable}" > "${EXECUTALBE_DEP_OUT}" 
                    ldd "${executable}" >> "${EXECUTALBE_DEP_OUT}" 
                    if [[ `uname` == "AIX" ]]; then
                        dump -H "${executable}" >> "${EXECUTALBE_DEP_OUT}" 
                    fi
                fi
            fi
        done
    else
        LOG_WARN "Can't access $INSTALL_DIR"
    fi
    if [[ -d /usr/lib/.ekran/ ]]; then
        if [[ ! $(uname) == "AIX" ]]; then
            find /usr/lib/.ekran/ -iname "*lib*hook*" -exec ldd {} + &> "$RES_DIR_DEPS"/libhookDeps.txt
        else
            find /usr/lib/.ekran/ -name "*lib*hook*" -exec ldd {} \; > "$RES_DIR_DEPS"/libhookDeps.txt
            find /usr/lib/.ekran/ -name "*lib*hook*" -exec dump -Xany -H {} \; >> "$RES_DIR_DEPS"/libhookDeps.txt
        fi
    else
        LOG_WARN "Can't access /usr/lib/.ekran/"
    fi
}

function ProcessSettings()
{
    # Checking access to settings file
    if [[ -e $SETTINGS_FILE ]]; then
        
        # Copy settings
        cp $SETTINGS_FILE $RES_DIR/settings.xml
        
        # Get install dir
        INSTALL_DIR="`echo -n $(grep InstallDir /etc/.ekran/settings.xml | sed "s|<\/*InstallDir>||g")`"
        if [[ -n $INSTALL_DIR ]]; then
            LOG_INFO "INSTALL_DIR=$INSTALL_DIR"
        else
            LOG_WARN "Can't open $INSTALL_DIR"
        fi
    else
        LOG_WARN "Can't open $SETTINGS_FILE"
    fi
}

function GetEkranProcessesStatus()
{
    RES_DIR_SERVIEMANAGER="$RES_DIR/service_manager.txt"
    if [[ `uname` == "SunOS" ]]; then
        echo "svcs : " >> $RES_DIR_SERVIEMANAGER
        svcs status EkranService >> $RES_DIR_SERVIEMANAGER
    elif [[ `uname` == "AIX" ]]; then
        echo "No service manager" >> $RES_DIR_SERVIEMANAGER
    else
        if [[ `command -v systemctl` ]]; then
            echo "systemctl :" >> $RES_DIR_SERVIEMANAGER
            systemctl status EkranService >> $RES_DIR_SERVIEMANAGER
        else
            echo "No service manager" >> $RES_DIR_SERVIEMANAGER
        fi
    fi

    RES_DIR_PROCESSES="$RES_DIR/EkranProcesses.txt"
    GREP="grep"
    if [[ `uname` == "SunOS" ]]; then
        GREP="/usr/xpg4/bin/grep"
    fi
    
    # Getstatus using ps
    ps -eo comm,user,pid,ppid,etime,time,pcpu,vsz | head -1 >> $RES_DIR_PROCESSES # heading
    # EkranGuiRecorde, where is 'r'? System cuts it, so it's ok.
    ps -eo comm,user,pid,ppid,etime,time,pcpu,vsz | ${GREP} -E 'EkranAgent|OfflinePool|ekran_recorder|EkranGuiRecorde' >> $RES_DIR_PROCESSES

    EKRAN_PROCESSES_ENVS="${RES_DIR}/processes_envs/"
    mkdir ${EKRAN_PROCESSES_ENVS}
    ps -eo comm,pid | ${GREP} -E 'EkranAgent|OfflinePool|ekran_recorder' | while read -r comm pid; do
        PROC_NAME=`basename $comm`
        if [[ `uname` == "SunOS" ]]; then
            GET_PROC_ENVS="pargs -e ${pid}"
        elif [[ `uname` == 'AIX' ]]; then
            GET_PROC_ENVS="ps eww ${pid}"
        else 
            GET_PROC_ENVS="cat /proc/${pid}/environ"
        fi
        ${GET_PROC_ENVS} > "${EKRAN_PROCESSES_ENVS}/${PROC_NAME}.${pid}"
    done
}

function ProcessesLibhookPreloaded()
{
    if [ `uname` == 'SunOS' ]; then
        MAPS="map"
        elif [ `uname` == 'AIX' ]; then
        MAPS="map"
        elif [ `uname` == 'Linux' ]; then
        MAPS="maps"
    fi
    
    # Search for libhook occurence in process's map file
    if [[ -d "/proc" ]]; then
        for d in /proc/*/ ; do
            if [[ -f "$d/maps" ]]; then
                if [[ `grep "libhook" "$d/$MAPS"` ]]; then
                    if [[ -f "$d/stat" ]]; then
                        STAT=`cat $d/stat`
                        STATA=( $STAT )
                        echo ${STATA[0]}${STATA[1]} >> "$RES_DIR/ProcessesLibhookPreloaded.txt"
                    else
                        local pid=`basename $d`
                        local pname=`ps -p "$pid" -o comm=`
                        echo "$pid($pname)" >> "$RES_DIR/ProcessesLibhookPreloaded.txt"
                    fi
                fi
            fi
        done
    else
        LOG_WARN "Can't access /proc"
    fi
}

function CollectDirectoriesInfo()
{
    local LIBS_DIR=/usr/lib/.ekran

    RES_DIR_INFO="$RES_DIR/permissions.txt"
    declare -a arr=(
        "/var/.ekran/"
        "/var/.ekran/internal"
        "/var/.ekran/internal/recorders"
        "/var/.ekran/internal/functions"
        "/var/.ekran/internal/RemoteUI"
        "/var/log/.ekran/"
        "/etc/.ekran/"
        "/proc/"
        "$LIBS_DIR"
        "."
    )
    if [[ "$(uname)" == "Linux" ]]; then
        arr+=("/etc/ld.so.preload")
    fi

    for i in "${arr[@]}"
    do
        printf "$i\n" >> "$RES_DIR_INFO"

        if [[ "$i" == "$LIBS_DIR" ]];then
            ls -Rla "$i" >> "$RES_DIR_INFO"
        else
            ls -la "$i" >> "$RES_DIR_INFO"
        fi
        
        printf "\n" >> "$RES_DIR_INFO"
    done

    local parent="$CURRENT_DIR"

    while true; do
        (ls -ld "$parent") >> "$RES_DIR_INFO"
        
        local child=$(cd "$parent"/../ && pwd)
        if [[ "${child}" = "/" ]]; then
            break
        fi
        parent="${child}"
    done
}

function CollectFilesInfo()
{
    RES_FILE_INFO="$RES_DIR/files.txt"
    declare -a arr=(
        "/etc/xdg/autostart/EkranGuiRecorder.desktop"
    )

    for i in "${arr[@]}"
    do
        if test -f "$i"; then
            STATUS="exists"
        else
            STATUS="does not exist"
        fi

        printf "$i - $STATUS\n" >> "$RES_FILE_INFO"
    done
}

function CollectSysInfo()
{
    RES_DIR_SYSINF="$RES_DIR/sysinfo.txt"
    echo "kernel name : "`uname -s` >> "$RES_DIR_SYSINF"
    echo "kernel release : "`uname -r` >> "$RES_DIR_SYSINF"
    echo "kernel version : "`uname -v` >> "$RES_DIR_SYSINF"
    echo "processor type : "`uname -p` >> "$RES_DIR_SYSINF"
    echo "the shell path : $SHELL" >> "$RES_DIR_SYSINF"
    
    # getting hidepid
    echo "proc info : " >> "$RES_DIR_SYSINF"
    mount | grep proc >> "$RES_DIR_SYSINF"
}

function CollectProcesses()
{
    RES_DID_PROCESSES="$RES_DIR/processes.txt"
    ps -ef >> "$RES_DID_PROCESSES"
}

function CollectNetworkInterfacesInfo()
{
    ifconfig -a >> "${RES_DIR}/ifconfig.txt"
}

function PingServer()
{
    SERVER_IP="`echo -n $(grep RemoteHost /etc/.ekran/settings.xml | sed "s|<\/*RemoteHost>||g")`"
    RES_DIR_PINGS="${RES_DIR}/server_pings.txt"
    RES_DIR_NSLOOKUPS="${RES_DIR}/server_hostnames_lookups.txt"
    while IFS=';' read -ra ADDR; do
        for ip in "${ADDR[@]}"; do
            if [[ ! $ip =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
                nslookup "${ip}" >> "${RES_DIR_NSLOOKUPS}"
            fi
            LOG_INFO "Pinging ${ip}..."
            ping -c 2 ${ip} >> "${RES_DIR_PINGS}"
            printf "\n" >> "${RES_DIR_PINGS}"
        done
    done <<< "${SERVER_IP}" 
}

function CollectSelinuxInfo()
{
    if [[ "$(uname)" != "Linux" ]]; then
        return
    fi

    RES_DIR_SELINUX="$RES_DIR/selinux.txt"

    if command -v sestatus &> /dev/null; then
        echo "Detected SELinux." >> "$RES_DIR_SELINUX"
        sestatus >> "$RES_DIR_SELINUX"

        ls -laZR /usr/lib/.ekran/ >> "$RES_DIR_SELINUX"
        ls -laZR /etc/.ekran/ >> "$RES_DIR_SELINUX"
        ls -laZ /var/.ekran/internal >> "$RES_DIR_SELINUX"
        ls -laZR "$INSTALL_DIR" >> "$RES_DIR_SELINUX"
    else
        echo "SELinux is not installed on this device." >> "$RES_DIR_SELINUX"
    fi
}

function EkranDiskUsage()
{
    RES_DIR_EKRAN_DISK_USAGE="${RES_DIR}/EkranDiskUsage.txt"
    du "/var/log/.ekran" >> "${RES_DIR_EKRAN_DISK_USAGE}"
    du "${INSTALL_DIR}" >> "${RES_DIR_EKRAN_DISK_USAGE}"
    du "/etc/.ekran" >> "${RES_DIR_EKRAN_DISK_USAGE}"
    du "/var/.ekran" >> "${RES_DIR_EKRAN_DISK_USAGE}"
    printf "General disk usage\n" >> "${RES_DIR_EKRAN_DISK_USAGE}"
    df >> "${RES_DIR_EKRAN_DISK_USAGE}"
}

function Archive()
{
    # Put getenv.log into archiving folder
    mv ./getenv.log $RES_DIR
    
    # Need to unzip in ./EkranGetent instead of /tmp/EkranGetent
    cd "$RES_DIR/../."
    OUT_ARCH_PATH="${CURRENT_DIR}/${ARCHIVE_NAME}.tar.gz"
    if [ `uname` == 'Linux' ]; then
        tar -czf ${OUT_ARCH_PATH} ./`basename "$RES_DIR"`
    else
        tar cf ${CURRENT_DIR}/${ARCHIVE_NAME}.tar ./`basename "$RES_DIR"`
        gzip -fq ${CURRENT_DIR}/${ARCHIVE_NAME}.tar
    fi
    chmod u=rw,g=,o= "${OUT_ARCH_PATH}"
}

function MoveTo()
{
    if [ ! -z "${MOVE_TO}" ]; then
        mv "${OUT_ARCH_PATH}" "${MOVE_TO}"
    fi
}

function CleanUp()
{
    rm -f ./getenv.log
    rm -rf ${RES_DIR}
}

IsRoot

# Parsing params
while getopts "t:s:h" arg
do
    case ${arg} in
        t) TICKET_ID=${OPTARG};;
        s) SILENT=${OPTARG};;
        h) Usage; exit 0;;
        *) Usage; exit 1;;
    esac
done

InitiateTmpDirectory
BuildArchiveName
CollectLogs
CollectSysInfo
CollectProcesses
ProcessSettings
CollectDependencies
GetEkranProcessesStatus
ProcessesLibhookPreloaded
CollectDirectoriesInfo
CollectFilesInfo
CollectNetworkInterfacesInfo
PingServer
EkranDiskUsage
CollectSelinuxInfo
Archive
MoveTo
CleanUp
